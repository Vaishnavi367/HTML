
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { BookOpen, Brain, Trophy, Clock, Target, Users, Star, Play } from "lucide-react";
import LessonCard from "@/components/LessonCard";
import QuizSection from "@/components/QuizSection";
import ProgressChart from "@/components/ProgressChart";
import AchievementBadge from "@/components/AchievementBadge";

const Index = () => {
  const [currentStreak, setCurrentStreak] = useState(7);
  const [totalPoints, setTotalPoints] = useState(2340);
  const [completedLessons, setCompletedLessons] = useState(23);

  const subjects = [
    { 
      name: "Mathematics", 
      progress: 78, 
      icon: Brain, 
      color: "bg-blue-500",
      lessons: 12,
      nextLesson: "Quadratic Equations"
    },
    { 
      name: "Science", 
      progress: 65, 
      icon: Target, 
      color: "bg-green-500",
      lessons: 8,
      nextLesson: "Chemical Reactions"
    },
    { 
      name: "History", 
      progress: 45, 
      icon: BookOpen, 
      color: "bg-purple-500",
      lessons: 6,
      nextLesson: "Renaissance Period"
    },
    { 
      name: "Literature", 
      progress: 89, 
      icon: Star, 
      color: "bg-orange-500",
      lessons: 15,
      nextLesson: "Poetry Analysis"
    }
  ];

  const recentAchievements = [
    { title: "Quiz Master", description: "Scored 100% on 5 quizzes", icon: Trophy, color: "text-yellow-500" },
    { title: "Study Streak", description: "7 days in a row", icon: Clock, color: "text-blue-500" },
    { title: "Fast Learner", description: "Completed 3 lessons today", icon: Play, color: "text-green-500" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-600 p-2 rounded-lg">
                <BookOpen className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">EduFlow</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                <Trophy className="h-3 w-3 mr-1" />
                {totalPoints} pts
              </Badge>
              <Avatar>
                <AvatarFallback className="bg-blue-600 text-white">JD</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, John!</h2>
          <p className="text-gray-600">Ready to continue your learning journey?</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Current Streak</p>
                  <p className="text-2xl font-bold text-orange-600">{currentStreak} days</p>
                </div>
                <Clock className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Points</p>
                  <p className="text-2xl font-bold text-blue-600">{totalPoints}</p>
                </div>
                <Trophy className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Completed</p>
                  <p className="text-2xl font-bold text-green-600">{completedLessons}</p>
                </div>
                <Target className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Study Group</p>
                  <p className="text-2xl font-bold text-purple-600">12</p>
                </div>
                <Users className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="lessons">Lessons</TabsTrigger>
            <TabsTrigger value="quiz">Practice Quiz</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {/* Subject Progress */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Your Subjects</CardTitle>
                  <CardDescription>Continue where you left off</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {subjects.map((subject, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-lg ${subject.color}`}>
                            <subject.icon className="h-4 w-4 text-white" />
                          </div>
                          <div>
                            <p className="font-medium">{subject.name}</p>
                            <p className="text-sm text-gray-500">Next: {subject.nextLesson}</p>
                          </div>
                        </div>
                        <Badge variant="outline">{subject.lessons} lessons</Badge>
                      </div>
                      <Progress value={subject.progress} className="h-2" />
                      <p className="text-xs text-gray-500 text-right">{subject.progress}% complete</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Recent Achievements */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Achievements</CardTitle>
                  <CardDescription>Great work! Keep it up</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {recentAchievements.map((achievement, index) => (
                    <AchievementBadge 
                      key={index}
                      title={achievement.title}
                      description={achievement.description}
                      icon={achievement.icon}
                      color={achievement.color}
                    />
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="lessons">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {subjects.map((subject, index) => (
                <LessonCard
                  key={index}
                  title={subject.name}
                  description={`Continue with ${subject.nextLesson}`}
                  progress={subject.progress}
                  icon={subject.icon}
                  color={subject.color}
                  totalLessons={subject.lessons}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="quiz">
            <QuizSection />
          </TabsContent>

          <TabsContent value="progress">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ProgressChart />
              <Card>
                <CardHeader>
                  <CardTitle>Learning Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Weekly Goal</span>
                      <span className="font-medium">5/7 days</span>
                    </div>
                    <Progress value={71} />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Monthly Progress</span>
                      <span className="font-medium">18/25 lessons</span>
                    </div>
                    <Progress value={72} />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Quiz Accuracy</span>
                      <span className="font-medium">87%</span>
                    </div>
                    <Progress value={87} />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Index;
