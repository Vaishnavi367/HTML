
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";

interface AchievementBadgeProps {
  title: string;
  description: string;
  icon: LucideIcon;
  color: string;
  isNew?: boolean;
}

const AchievementBadge = ({ 
  title, 
  description, 
  icon: Icon, 
  color,
  isNew = false 
}: AchievementBadgeProps) => {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center space-x-3">
          <div className="flex-shrink-0">
            <div className="p-2 bg-gray-100 rounded-lg">
              <Icon className={`h-5 w-5 ${color}`} />
            </div>
          </div>
          <div className="flex-grow">
            <div className="flex items-center space-x-2">
              <h4 className="font-medium text-gray-900">{title}</h4>
              {isNew && (
                <Badge variant="destructive" className="text-xs px-2 py-1">
                  New!
                </Badge>
              )}
            </div>
            <p className="text-sm text-gray-600">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AchievementBadge;
