
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, ArrowRight, RotateCcw, Trophy } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  subject: string;
}

const QuizSection = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const questions: Question[] = [
    {
      id: 1,
      question: "What is the derivative of x²?",
      options: ["x", "2x", "x²", "2"],
      correctAnswer: 1,
      explanation: "The derivative of x² is 2x using the power rule.",
      subject: "Mathematics"
    },
    {
      id: 2,
      question: "Which element has the chemical symbol 'O'?",
      options: ["Gold", "Oxygen", "Silver", "Iron"],
      correctAnswer: 1,
      explanation: "Oxygen has the chemical symbol 'O' on the periodic table.",
      subject: "Science"
    },
    {
      id: 3,
      question: "Who wrote 'Romeo and Juliet'?",
      options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
      correctAnswer: 1,
      explanation: "William Shakespeare wrote the famous play 'Romeo and Juliet'.",
      subject: "Literature"
    },
    {
      id: 4,
      question: "What year did World War II end?",
      options: ["1944", "1945", "1946", "1947"],
      correctAnswer: 1,
      explanation: "World War II ended in 1945 with the surrender of Japan.",
      subject: "History"
    }
  ];

  const handleAnswerSelect = (answerIndex: number) => {
    if (showResult) return;
    setSelectedAnswer(answerIndex);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;

    const isCorrect = selectedAnswer === questions[currentQuestion].correctAnswer;
    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);
    
    if (isCorrect) {
      setScore(score + 1);
      toast({
        title: "Correct! 🎉",
        description: questions[currentQuestion].explanation,
      });
    } else {
      toast({
        title: "Not quite right",
        description: questions[currentQuestion].explanation,
        variant: "destructive",
      });
    }

    setShowResult(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnswers([]);
    setQuizCompleted(false);
  };

  const currentQ = questions[currentQuestion];
  const progressPercent = ((currentQuestion + (showResult ? 1 : 0)) / questions.length) * 100;

  if (quizCompleted) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 p-4 bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center">
            <Trophy className="h-8 w-8 text-blue-600" />
          </div>
          <CardTitle className="text-2xl">Quiz Completed!</CardTitle>
          <CardDescription>Great job on finishing the practice quiz</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 text-center">
          <div className="space-y-2">
            <div className="text-4xl font-bold text-blue-600">{percentage}%</div>
            <p className="text-gray-600">You scored {score} out of {questions.length} questions correctly</p>
          </div>
          
          <div className="space-y-3">
            {percentage >= 80 && (
              <Badge className="bg-green-100 text-green-800 px-4 py-2">
                <Trophy className="h-4 w-4 mr-2" />
                Excellent Performance!
              </Badge>
            )}
            {percentage >= 60 && percentage < 80 && (
              <Badge className="bg-yellow-100 text-yellow-800 px-4 py-2">
                Good Job!
              </Badge>
            )}
            {percentage < 60 && (
              <Badge className="bg-red-100 text-red-800 px-4 py-2">
                Keep Practicing!
              </Badge>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="p-3 bg-green-50 rounded-lg">
              <div className="font-medium text-green-800">Correct</div>
              <div className="text-2xl font-bold text-green-600">{score}</div>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <div className="font-medium text-red-800">Incorrect</div>
              <div className="text-2xl font-bold text-red-600">{questions.length - score}</div>
            </div>
          </div>

          <Button onClick={resetQuiz} className="w-full">
            <RotateCcw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <Badge variant="outline">{currentQ.subject}</Badge>
          <span className="text-sm text-gray-500">
            Question {currentQuestion + 1} of {questions.length}
          </span>
        </div>
        <Progress value={progressPercent} className="h-2" />
      </CardHeader>
      
      <CardContent className="space-y-6">
        <div>
          <CardTitle className="text-xl mb-4">{currentQ.question}</CardTitle>
          
          <div className="space-y-3">
            {currentQ.options.map((option, index) => {
              let buttonStyle = "justify-start text-left h-auto p-4 ";
              
              if (showResult) {
                if (index === currentQ.correctAnswer) {
                  buttonStyle += "bg-green-100 border-green-500 text-green-800 hover:bg-green-100";
                } else if (index === selectedAnswer && selectedAnswer !== currentQ.correctAnswer) {
                  buttonStyle += "bg-red-100 border-red-500 text-red-800 hover:bg-red-100";
                } else {
                  buttonStyle += "bg-gray-50 text-gray-500";
                }
              } else {
                buttonStyle += selectedAnswer === index 
                  ? "bg-blue-100 border-blue-500 text-blue-800" 
                  : "bg-white border-gray-200 hover:bg-gray-50";
              }

              return (
                <Button
                  key={index}
                  variant="outline"
                  className={buttonStyle}
                  onClick={() => handleAnswerSelect(index)}
                  disabled={showResult}
                >
                  <div className="flex items-center space-x-3 w-full">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-medium">
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="flex-grow">{option}</span>
                    {showResult && index === currentQ.correctAnswer && (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    )}
                    {showResult && index === selectedAnswer && selectedAnswer !== currentQ.correctAnswer && (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                  </div>
                </Button>
              );
            })}
          </div>
        </div>

        <div className="flex justify-between items-center pt-4">
          <div className="text-sm text-gray-500">
            Score: {score}/{currentQuestion + (showResult ? 1 : 0)}
          </div>
          
          {!showResult ? (
            <Button 
              onClick={handleSubmitAnswer}
              disabled={selectedAnswer === null}
            >
              Submit Answer
            </Button>
          ) : (
            <Button onClick={handleNextQuestion}>
              {currentQuestion < questions.length - 1 ? (
                <>
                  Next Question
                  <ArrowRight className="h-4 w-4 ml-2" />
                </>
              ) : (
                "Finish Quiz"
              )}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuizSection;
