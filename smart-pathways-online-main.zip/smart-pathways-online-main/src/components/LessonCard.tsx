
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Play, Clock, CheckCircle } from "lucide-react";
import { LucideIcon } from "lucide-react";

interface LessonCardProps {
  title: string;
  description: string;
  progress: number;
  icon: LucideIcon;
  color: string;
  totalLessons: number;
  duration?: string;
  difficulty?: "Beginner" | "Intermediate" | "Advanced";
}

const LessonCard = ({ 
  title, 
  description, 
  progress, 
  icon: Icon, 
  color, 
  totalLessons,
  duration = "45 min",
  difficulty = "Intermediate"
}: LessonCardProps) => {
  return (
    <Card className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className={`p-3 rounded-xl ${color} group-hover:scale-110 transition-transform`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          <Badge 
            variant={difficulty === "Beginner" ? "secondary" : difficulty === "Advanced" ? "destructive" : "default"}
            className="text-xs"
          >
            {difficulty}
          </Badge>
        </div>
        <CardTitle className="text-xl font-bold group-hover:text-blue-600 transition-colors">
          {title}
        </CardTitle>
        <CardDescription className="text-sm text-gray-600">
          {description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Progress</span>
            <span className="font-medium">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
        
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center space-x-1">
            <Clock className="h-4 w-4" />
            <span>{duration}</span>
          </div>
          <div className="flex items-center space-x-1">
            <CheckCircle className="h-4 w-4" />
            <span>{Math.floor(progress * totalLessons / 100)}/{totalLessons} lessons</span>
          </div>
        </div>
        
        <Button 
          className="w-full group-hover:bg-blue-600 group-hover:shadow-md transition-all"
          size="sm"
        >
          <Play className="h-4 w-4 mr-2" />
          {progress > 0 ? "Continue Learning" : "Start Learning"}
        </Button>
      </CardContent>
    </Card>
  );
};

export default LessonCard;
